const endpoint = "../json/alunoList.json";
const tbody = document.getElementById('table-value');

const fetchAPI = () =>{
    const result = fetch(endpoint).then((response)=> response.json()).then((alunos) => {
        console.log(alunos);
        
    });
    console.log(result);

}